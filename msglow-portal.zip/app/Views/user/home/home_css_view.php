<style>
  .list-padding {
    padding-bottom: 8px;
  }

  .card-text {
    color: #6e6b7b;
  }

  .pointer {
    cursor: pointer;
  }

  path {
    fill: #fff;
  }

  polygon {
    fill: #fff;
  }

  circle {
    fill: #fff;
  }
</style>