<!-- Start CSS -->
<link rel="apple-touch-icon" href="<?= base_url('assets/ico/apple-icon-120.html'); ?>">
<link rel="shortcut icon" type="image/x-icon" href="https://pixinvent.com/demo/vuexy-html-bootstrap-admin-template/app-assets/images/ico/favicon.ico">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;700;900&display=swap" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/vendors.min.css'); ?>">
<link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css'); ?>">
<link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/bootstrap-extended.min.css'); ?>">
<link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/colors.min.css'); ?>">
<link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/components.min.css'); ?>">
<link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/vertical-menu.min.css'); ?>">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

<style>
    .toast {
        margin-top: 45px !important;
    }
</style>
<!-- End CSS-->