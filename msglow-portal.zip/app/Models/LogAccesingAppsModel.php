<?php

namespace App\Models;

use CodeIgniter\Model;

class LogAccesingAppsModel extends Model
{
    protected $table      = 't_log_accesing_apps';
    protected $primaryKey = 'log_accesing_apps_pid';
}
